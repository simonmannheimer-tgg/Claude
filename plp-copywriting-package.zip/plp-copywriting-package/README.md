# PLP Copywriting Package — The Good Guys
Generated: 2026-04-21

## Contents

### process/
Core process and reference documents that govern PLP copywriting:
- `01-plp-intros.md` — **Process 01**: PLP intro copy rules (the primary spec)
- `00-tov-language-reference.md` — Tone of voice + banned word list (read before any writing task)
- `08-eav-mapping.md` — Process 08: EAV entity/attribute mapping (run before PLP copy)
- `04-content-analysis.md` — Process 04: Content analysis + query fanout
- `05-faq-category-copy.md` — Process 05: FAQ + category copy (companion to PLP intros)
- `02-metadata-generation.md` — Process 02: Meta title + description writing

### agents/
Claude agent definition files (system prompts for specialist agents):
- `plp-copywriter.md` — Primary PLP intro copy agent
- `eav-researcher.md` — EAV mapping agent (prerequisite for plp-copywriter)
- `faq-writer.md` — FAQ + category copy agent

### scripts/
Python utility scripts for batch production and QA:
- `plp-qa-audit.py` — QA audit script for reviewing PLP copy quality
- `merge-plp-outputs.py` — Merges multiple batch output files into a single CSV
- `fix-clone-openers.py` — Detects and fixes cloned/repeated sentence openers
- `fix-critical-rows.py` — Targets and rewrites rows flagged as critical failures
- `generate-md-files.py` — Generates per-category markdown files from CSV

### outputs/csv/
Batch production outputs in CSV format:
- `plp-all-batches-2026-03-19.csv` — Full merged output (all batches, Mar 2026)
- `plp-fix-candidates-2026-03-19.csv` — Rows flagged for rewrite
- `TGG - SEO WIP _ SM - PLP Intro (Brand Cat).csv` — Master working spreadsheet

### outputs/markdown/
Individual batch outputs in markdown format:
- `plp-batch1-priority30-2026-03-19.md` — Priority 30 categories
- `plp-batch-2-2026-03-19.md` — Batch 2
- `plp-batch-3-2026-03-19.md` — Batch 3
- `plp-batch-4-2026-03-19.md` — Batch 4

### briefs/
Production briefs:
- `PLP-Batch-Production-Brief-2026-03-19.md` — Full batch production brief (Mar 2026)

### drafts/
Experimental / version-2 drafts (not yet canonical):
- `01-plp-intros-v2.md` — Draft v2 of Process 01
- `plp-copywriter-v2.md` — Draft v2 of the agent definition
- `plp-fix-pass.md` — Spec for the fix-pass workflow

### workflows/
GitHub Actions:
- `plp-merge.yml` — Workflow to merge PLP output branches

## Recommended Workflow Order
1. `08-eav-mapping.md` → run eav-researcher agent
2. `04-content-analysis.md` → run content-analyst agent
3. `01-plp-intros.md` → run plp-copywriter agent
4. `02-metadata-generation.md` → run metadata-writer agent
5. `05-faq-category-copy.md` → run faq-writer agent
